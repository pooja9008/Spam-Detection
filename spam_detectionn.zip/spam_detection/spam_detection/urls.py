from django.urls import path, include
from django.contrib import admin
from api.views import RegisterView, mark_spam, search, MyTokenObtainPairView, MyTokenRefreshView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/register/', RegisterView.as_view(), name='register'),
    path('api/mark_spam/', mark_spam, name='mark_spam'),
    path('api/search/', search, name='search'),
    path('api/token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
]
