from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view, permission_classes
from django.db.models import Q
from .models import User, Contact
from .serializers import UserSerializer, ContactSerializer
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.permissions import AllowAny

class MyTokenObtainPairView(TokenObtainPairView):
    permission_classes = (AllowAny,)

class MyTokenRefreshView(TokenRefreshView):
    permission_classes = (AllowAny,)

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def mark_spam(request):
    phone_number = request.data.get('phone_number')
    if phone_number:
        Contact.objects.filter(phone_number=phone_number).update(is_spam=True)
        return Response({'status': 'Number marked as spam'}, status=status.HTTP_200_OK)
    return Response({'error': 'Phone number is required'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def search(request):
    query = request.query_params.get('query', '')
    results = User.objects.filter(
        Q(username__icontains=query) | Q(phone_number__icontains=query)
    ).values('username', 'phone_number')
    contacts = Contact.objects.filter(
        Q(name__icontains=query) | Q(phone_number__icontains=query)
    ).values('name', 'phone_number', 'is_spam')
    return Response({'users': list(results), 'contacts': list(contacts)}, status=status.HTTP_200_OK)
