# register user 
curl --location 'http://127.0.0.1:8000/api/register/' \
--header 'Content-Type: application/json' \
--data-raw '{
        "username": "testuser1",
        "phone_number": "1234567890",
        "email": "testuser1@example.com",
        "password": "testpassword1234"
    }'

# search user
curl --location 'http://127.0.0.1:8000/api/search/?query=testuser'

# set user as spam 
curl --location 'http://127.0.0.1:8000/api/mark_spam/' \
--header 'Content-Type: application/json' \
--data '{
    "phone_number": 1234567890
}'